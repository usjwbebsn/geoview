"use client";
import * as React from "react";
import * as SwitchPrimitives from "@radix-ui/react-switch";
import { cn } from "@/lib/utils";

const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitives.Root>,
  React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root>
>(({ className, ...props }, ref) => (
  <SwitchPrimitives.Root
    ref={ref}
    className={cn(
      "peer inline-flex h-4 w-7 shrink-0 cursor-pointer items-center rounded-full border border-panel-border transition-colors",
      "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-accent-cyan",
      "disabled:cursor-not-allowed disabled:opacity-50",
      "data-[state=checked]:bg-accent-cyan data-[state=unchecked]:bg-panel-hover",
      className
    )}
    {...props}
  >
    <SwitchPrimitives.Thumb className={cn(
      "pointer-events-none block h-3 w-3 rounded-full bg-text-muted shadow-lg ring-0 transition-transform",
      "data-[state=checked]:translate-x-3.5 data-[state=unchecked]:translate-x-0.5",
      "data-[state=checked]:bg-surface"
    )} />
  </SwitchPrimitives.Root>
));
Switch.displayName = SwitchPrimitives.Root.displayName;

export { Switch };
